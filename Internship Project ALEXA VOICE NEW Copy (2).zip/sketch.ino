#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ESP32Servo.h>
#include <WiFi.h>
#include <SinricPro.h>
#include <SinricProSwitch.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

// ===== WiFi =====
#define WIFI_SSID "Wokwi-GUEST"
#define WIFI_PASS ""

// ===== Sinric Credentials =====
#define APP_KEY    "49bcabd8-d990-4d4f-937c-efbd9b7fb954"
#define APP_SECRET "bc300bdd-659e-441b-99a4-8df2c1bb9547-08d07c1e-8c58-401b-9965-772f4ac58014"

#define FAN_ID   "6a3039e509efd1746c0da8e2"
#define LIGHT_ID "6a303a6e09efd1746c0da938"
#define PUMP_ID  "6a303ac629c6be334260606b"

// ===== OLED =====
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// ===== Servo Objects =====
Servo fanServo;
Servo pumpServo;

// ===== Pins =====
#define FAN_SERVO_PIN   18
#define PUMP_SERVO_PIN  19

#define LIGHT_LED       25

#define FAN_BUTTON      32
#define LIGHT_BUTTON    33
#define PUMP_BUTTON     27

#define POT_PIN         34

// ===== Device States =====
bool fanState = false;
bool lightState = false;
bool pumpState = false;

// ===== Button Memory =====
bool lastFanButton = HIGH;
bool lastLightButton = HIGH;
bool lastPumpButton = HIGH;

// ===== Fan Animation =====
int fanAngle = 0;
bool fanDirection = true;

// ===== Pump Animation =====
int pumpAngle = 0;
bool pumpDirection = true;

// ===== Function Prototypes =====
void updateDisplay();
void setupSinricPro();

bool onFanPowerState(const String &deviceId, bool &state);
bool onLightPowerState(const String &deviceId, bool &state);
bool onPumpPowerState(const String &deviceId, bool &state);

void setup() {

  Serial.begin(115200);

  // ===== WiFi =====
  WiFi.begin(WIFI_SSID, WIFI_PASS);

  Serial.print("Connecting WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi Connected");

  // ===== Pins =====
  pinMode(LIGHT_LED, OUTPUT);

  pinMode(FAN_BUTTON, INPUT_PULLUP);
  pinMode(LIGHT_BUTTON, INPUT_PULLUP);
  pinMode(PUMP_BUTTON, INPUT_PULLUP);

  digitalWrite(LIGHT_LED, LOW);

  // ===== Servos =====
  fanServo.attach(FAN_SERVO_PIN);
  pumpServo.attach(PUMP_SERVO_PIN);

  fanServo.write(90);
  pumpServo.write(90);

  delay(500);

  // ===== OLED =====
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED Failed");
    while (1);
  }

  display.clearDisplay();
  display.display();

  updateDisplay();

  // ===== Sinric =====
  setupSinricPro();
}
void loop() {

  // Handle Sinric/Alexa requests
  SinricPro.handle();

  // ===== FAN BUTTON =====
 // bool fanBtn = digitalRead(FAN_BUTTON);

  //if (lastFanButton == HIGH && fanBtn == LOW) {

  //  fanState = !fanState;

  /* if (!fanState) {
      fanServo.write(90);
    }

    updateDisplay();
    delay(200);
  }

  lastFanButton = fanBtn;

  // ===== LIGHT BUTTON =====
  bool lightBtn = digitalRead(LIGHT_BUTTON);

  if (lastLightButton == HIGH && lightBtn == LOW) {

    lightState = !lightState;

    digitalWrite(LIGHT_LED, lightState);

    updateDisplay();
    delay(200);
  }

  lastLightButton = lightBtn;

  // ===== PUMP BUTTON =====
  bool pumpBtn = digitalRead(PUMP_BUTTON);

  if (lastPumpButton == HIGH && pumpBtn == LOW) {

    pumpState = !pumpState;

    if (!pumpState) {
      pumpServo.write(90);
    }

    updateDisplay();
    delay(200);
  }

  lastPumpButton = pumpBtn;*/

  // ===== FAN ANIMATION =====
  if (fanState) {

    if (fanDirection) {

      fanAngle += 8;

      if (fanAngle >= 180) {
        fanAngle = 180;
        fanDirection = false;
      }

    } else {

      fanAngle -= 8;

      if (fanAngle <= 0) {
        fanAngle = 0;
        fanDirection = true;
      }
    }

    fanServo.write(fanAngle);
  }

  // ===== PUMP ANIMATION =====
  if (pumpState) {

    if (pumpDirection) {

      pumpAngle += 3;

      if (pumpAngle >= 180) {
        pumpAngle = 180;
        pumpDirection = false;
      }

    } else {

      pumpAngle -= 3;

      if (pumpAngle <= 0) {
        pumpAngle = 0;
        pumpDirection = true;
      }
    }

    pumpServo.write(pumpAngle);
  }

  // ===== OLED Refresh =====
  static unsigned long lastUpdate = 0;

  if (millis() - lastUpdate > 500) {
    updateDisplay();
    lastUpdate = millis();
  }

  delay(20);
}

void updateDisplay() {

  int potValue = analogRead(POT_PIN);
  int powerWatts = map(potValue, 0, 4095, 0, 2000);

  display.clearDisplay();

  display.setTextSize(1);
  display.setTextColor(WHITE);

  display.setCursor(0, 0);
  display.println("SMART SWITCHBOARD");

  display.setCursor(0, 16);
  display.print("FAN   : ");
  display.println(fanState ? "ON" : "OFF");

  display.setCursor(0, 28);
  display.print("LIGHT : ");
  display.println(lightState ? "ON" : "OFF");

  display.setCursor(0, 40);
  display.print("PUMP  : ");
  display.println(pumpState ? "ON" : "OFF");

  display.setCursor(0, 54);
  display.print("POWER:");
  display.print(powerWatts);
  display.print("W");

  display.display();
}

// ================= FAN =================
bool onFanPowerState(const String &deviceId, bool &state) {

  Serial.print("Fan state received = ");
  Serial.println(state);

  fanState = state;

  if (!fanState) {
    fanServo.write(90);
  }

  updateDisplay();

  return true;
}

// ================= LIGHT =================
bool onLightPowerState(const String &deviceId, bool &state) {

  Serial.print("Light state received = ");
  Serial.println(state);

  lightState = state;

  digitalWrite(LIGHT_LED, lightState);

  updateDisplay();

  return true;
}

// ================= PUMP =================
bool onPumpPowerState(const String &deviceId, bool &state) {

  Serial.print("Pump state received = ");
  Serial.println(state);

  pumpState = state;

  if (!pumpState) {
    pumpServo.write(90);
  }

  updateDisplay();

  return true;
}

// ================= SINRIC =================
void setupSinricPro() {

  SinricProSwitch &fan = SinricPro[FAN_ID];
  SinricProSwitch &light = SinricPro[LIGHT_ID];
  SinricProSwitch &pump = SinricPro[PUMP_ID];

  fan.onPowerState(onFanPowerState);
  light.onPowerState(onLightPowerState);
  pump.onPowerState(onPumpPowerState);

  SinricPro.begin(APP_KEY, APP_SECRET);

  Serial.println("Sinric Pro Connected");
}